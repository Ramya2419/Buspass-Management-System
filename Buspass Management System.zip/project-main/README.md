The topic of the project is Bus Pass Management System.
It deals with the bus pass generation procedure by the administrator.
It makes the process digital and efficient.
(HTML,CSS in front end and PHP,MySQL in backend)
